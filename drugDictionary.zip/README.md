# Drug Dictionary

Drug Dictinary is a website for pharmacy students, it contains more than 200 drug with its molecular formula, IUPAC name, structual formula etc.

## Installation

Use the package manager [npm] to install the packages.

```bash
npm install 
```

## Authors
Mohammed Hassan (BE Computer Science Engineering) \
linkedIn: /mohammed-hassan-343b00215



